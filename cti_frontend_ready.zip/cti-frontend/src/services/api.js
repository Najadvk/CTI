import axios from 'axios';
const API_BASE = "https://your-backend.onrender.com";
export const fetchCTI = async (query) => {
    try {
        const response = await axios.get(`${API_BASE}/lookup`, { params: { query } });
        return response.data;
    } catch (error) {
        console.error("Error fetching CTI data:", error);
        return null;
    }
};