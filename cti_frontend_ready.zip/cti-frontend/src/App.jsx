import React, { useState } from 'react';
import SearchBox from './components/SearchBox';
import ResultsTabs from './components/ResultsTabs';
import { fetchCTI } from './services/api';

export default function App() {
    const [results, setResults] = useState(null);
    const handleSearch = async (query) => {
        const data = await fetchCTI(query);
        setResults(data);
    };
    return (
        <div className="p-4 max-w-4xl mx-auto">
            <h1 className="text-2xl font-bold mb-4">Cloud CTI Platform</h1>
            <SearchBox onSearch={handleSearch} />
            {results && <ResultsTabs results={results} />}
        </div>
    );
}