import React, { useState } from 'react';
export default function SearchBox({ onSearch }) {
    const [query, setQuery] = useState("");
    const handleSubmit = (e) => {
        e.preventDefault();
        if (query) onSearch(query);
    };
    return (
        <form onSubmit={handleSubmit} className="mb-4">
            <input
                type="text"
                className="border p-2 w-2/3"
                placeholder="Enter IP, domain, hash, URL, or email"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
            />
            <button type="submit" className="bg-blue-500 text-white px-4 py-2 ml-2">Search</button>
        </form>
    );
}