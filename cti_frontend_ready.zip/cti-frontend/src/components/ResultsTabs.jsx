import React, { useState } from 'react';
import ExportButton from './ExportButton';
export default function ResultsTabs({ results }) {
    const tabs = Object.keys(results);
    const [activeTab, setActiveTab] = useState(tabs[0]);
    return (
        <div>
            <div className="flex border-b mb-2">
                {tabs.map(tab => (
                    <button
                        key={tab}
                        className={`px-4 py-2 ${activeTab===tab ? 'border-b-2 border-blue-500 font-bold' : ''}`}
                        onClick={() => setActiveTab(tab)}
                    >{tab}</button>
                ))}
            </div>
            <div className="p-2">
                <pre className="overflow-x-auto bg-gray-100 p-2 rounded">
                    {JSON.stringify(results[activeTab], null, 2)}
                </pre>
            </div>
            <ExportButton data={results[activeTab]} />
        </div>
    );
}