import React from 'react';
export default function ExportButton({ data }) {
    const handleExport = (format) => {
        if (!data) return;
        let blob;
        if (format === 'json') {
            blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        } else {
            const rows = [];
            for (const key in data) {
                if (typeof data[key] === 'object') {
                    rows.push(`${key},\"${JSON.stringify(data[key])}\"`);
                } else {
                    rows.push(`${key},${data[key]}`);
                }
            }
            blob = new Blob([rows.join('\n')], { type: 'text/csv' });
        }
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `cti_export.${format}`;
        a.click();
    };
    return (
        <div className="mt-2">
            <button onClick={() => handleExport('json')} className="bg-green-500 text-white px-2 py-1 mr-2">Export JSON</button>
            <button onClick={() => handleExport('csv')} className="bg-yellow-500 text-white px-2 py-1">Export CSV</button>
        </div>
    );
}